module.exports = {

  // mongoURI:
    
  // mongoURI: "mongodb://localhost/Auth_passport",

  secretOrKey: "secret",

  PORT: 5000,

  NODE_ENV: "development",

  JWT_KEY: "a937{*Xe:krM&\&qDnwJBgs)7Y",
};
